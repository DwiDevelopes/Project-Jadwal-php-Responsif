

<?php $__env->startSection('content'); ?>
    <?php if(auth()->guard()->check()): ?>
        <h2>Selamat datang, <?php echo e(Auth::user()->name); ?>!</h2>
        <p>Ini adalah halaman beranda khusus pengguna yang sudah login.</p>
    <?php endif; ?>

    <?php if(auth()->guard()->guest()): ?>
        <h2>Selamat datang di halaman Beranda!</h2>
        <p>Silakan <a href="<?php echo e(route('login')); ?>">login</a> untuk melanjutkan.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_Akhir\akhir\jadwalkegiatan\resources\views/backend/beranda.blade.php ENDPATH**/ ?>