<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FC Barcelona - Official Fan Site</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="icon" type="image/x-icon" href="https://upload.wikimedia.org/wikipedia/id/thumb/4/47/FC_Barcelona_%28crest%29.svg/1183px-FC_Barcelona_%28crest%29.svg.png">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --barca-blue: #004D98;
            --barca-red: #A50044;
            --barca-yellow: #EDBB00;
            --light-bg: #f5f5f5;
            --dark-text: #333;
            --light-text: #fff;
        }

        body {
            background-color: var(--light-bg);
            color: var(--dark-text);
            line-height: 1.6;
        }

        /* Header Styles */
        header {
            background: linear-gradient(135deg, var(--barca-blue), var(--barca-red));
            color: var(--light-text);
            padding: 1rem 0;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            display: flex;
            align-items: center;
        }

        .logo img {
            height: 60px;
            margin-right: 15px;
        }

        .logo h1 {
            font-size: 1.8rem;
            font-weight: 700;
        }

        nav ul {
            display: flex;
            list-style: none;
        }

        nav ul li {
            margin-left: 25px;
        }

        nav ul li a {
            color: var(--light-text);
            text-decoration: none;
            font-weight: 600;
            font-size: 1.1rem;
            transition: color 0.3s;
        }

        nav ul li a:hover {
            color: var(--barca-yellow);
        }

        .mobile-menu {
            display: none;
            font-size: 1.5rem;
            cursor: pointer;
        }

        /* Hero Section */
        .hero {
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), 
                        url('https://www.fcbarcelona.com/fcbarcelona/photo/2025/05/21/a8784d04-590a-439d-a04f-be40926acaeb/SET_Jugadors.jpg');
            background-size: cover;
            background-position: center;
            color: var(--light-text);
            padding: 100px 0;
            text-align: center;
        }

        .hero h2 {
            font-size: 3rem;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }

        .hero p {
            font-size: 1.2rem;
            max-width: 700px;
            margin: 0 auto 30px;
        }

        .btn {
            display: inline-block;
            background-color: var(--barca-yellow);
            color: var(--dark-text);
            padding: 12px 30px;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 700;
            font-size: 1.1rem;
            transition: all 0.3s;
        }

        .btn:hover {
            background-color: var(--light-text);
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        /* Section Styles */
        section {
            padding: 80px 0;
        }

        .section-title {
            text-align: center;
            margin-bottom: 50px;
            position: relative;
        }

        .section-title h2 {
            font-size: 2.5rem;
            color: var(--barca-blue);
            display: inline-block;
            padding-bottom: 10px;
        }

        .section-title h2:after {
            content: '';
            position: absolute;
            width: 80px;
            height: 4px;
            background-color: var(--barca-red);
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
        }

        /* Players Section */
        .players-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 30px;
        }

        .player-card {
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .player-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
        }

        .player-img {
            height: 300px;
            overflow: hidden;
        }

        .player-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s;
        }

        .player-card:hover .player-img img {
            transform: scale(1.1);
        }

        .player-info {
            padding: 20px;
            text-align: center;
        }

        .player-info h3 {
            font-size: 1.4rem;
            margin-bottom: 5px;
            color: var(--barca-blue);
        }

        .player-info p {
            color: var(--barca-red);
            font-weight: 600;
            margin-bottom: 10px;
        }

        .player-stats {
            display: flex;
            justify-content: space-around;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #eee;
        }

        .stat {
            text-align: center;
        }

        .stat-value {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--barca-blue);
        }

        .stat-label {
            font-size: 0.8rem;
            color: #777;
        }

        /* Gallery Section */
        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }

        .gallery-item {
            border-radius: 10px;
            overflow: hidden;
            height: 250px;
            position: relative;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .gallery-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s;
        }

        .gallery-item:hover img {
            transform: scale(1.1);
        }

        .gallery-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: linear-gradient(transparent, rgba(0, 0, 0, 0.8));
            color: white;
            padding: 20px;
            transform: translateY(100%);
            transition: transform 0.3s;
        }

        .gallery-item:hover .gallery-overlay {
            transform: translateY(0);
        }

        /* History Section */
        .history-content {
            display: flex;
            align-items: center;
            gap: 40px;
        }

        .history-text {
            flex: 1;
        }

        .history-image {
            flex: 1;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }

        .history-image img {
            width: 100%;
            height: auto;
            display: block;
        }

        /* Footer */
        footer {
            background: linear-gradient(135deg, var(--barca-blue), var(--barca-red));
            color: var(--light-text);
            padding: 60px 0 20px;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            margin-bottom: 40px;
        }

        .footer-column h3 {
            font-size: 1.5rem;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 10px;
        }

        .footer-column h3:after {
            content: '';
            position: absolute;
            width: 50px;
            height: 3px;
            background-color: var(--barca-yellow);
            bottom: 0;
            left: 0;
        }

        .footer-column p {
            margin-bottom: 15px;
        }

        .social-links {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }

        .social-links a {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            color: var(--light-text);
            text-decoration: none;
            transition: all 0.3s;
        }

        .social-links a:hover {
            background-color: var(--barca-yellow);
            color: var(--dark-text);
            transform: translateY(-5px);
        }

        .footer-bottom {
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* Responsive Styles */
        @media (max-width: 992px) {
            .history-content {
                flex-direction: column;
            }
            
            .history-text, .history-image {
                flex: none;
                width: 100%;
            }
        }

        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                text-align: center;
            }
            
            .logo {
                margin-bottom: 15px;
                justify-content: center;
            }
            
            nav ul {
                margin-top: 15px;
                flex-wrap: wrap;
                justify-content: center;
            }
            
            nav ul li {
                margin: 0 10px 10px;
            }
            
            .hero h2 {
                font-size: 2.2rem;
            }
            
            .hero p {
                font-size: 1rem;
            }
            
            .section-title h2 {
                font-size: 2rem;
            }
        }

        @media (max-width: 576px) {
            .mobile-menu {
                display: block;
                position: absolute;
                top: 20px;
                right: 20px;
            }
            
            nav {
                display: none;
                width: 100%;
                margin-top: 20px;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
            }
            
            nav ul li {
                margin: 0 0 15px;
            }
            
            .hero {
                padding: 60px 0;
            }
            
            .hero h2 {
                font-size: 1.8rem;
            }
            
            section {
                padding: 50px 0;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <img src="https://upload.wikimedia.org/wikipedia/en/thumb/4/47/FC_Barcelona_%28crest%29.svg/800px-FC_Barcelona_%28crest%29.svg.png" alt="Barcelona Logo">
                    <h1>FC BARCELONA</h1>
                </div>
                <div class="mobile-menu">
                    <i class="fas fa-bars"></i>
                </div>
                <nav>
                    <ul>
                        <li><a href="#home">Beranda</a></li>
                        <li><a href="#players">Pemain</a></li>
                        <li><a href="#gallery">Galeri</a></li>
                        <li><a href="#history">Sejarah</a></li>
                        <li><a href="#contact">Kontak</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero" id="home">
        <div class="container">
            <h2>MÉS QUE UN CLUB</h2>
            <p>Lebih dari Sekadar Klub - Bergabunglah dengan komunitas penggemar FC Barcelona di seluruh dunia dan saksikan kehebatan tim legendaris ini.</p>
            <a href="#players" class="btn">Jelajahi Pemain</a>
        </div>
    </section>

<!-- Players Section -->
<section id="players">
    <div class="container">
        <div class="section-title">
            <h2>Pemain Barcelona - Musim 2023/2024</h2>
        </div>
        <div class="players-grid">
            <!-- Kiper -->
            <div class="player-card">
                <div class="player-img">
                    <img src="https://platform.bavarianfootballworks.com/wp-content/uploads/sites/24/2025/10/gettyimages-2232425926.jpg?quality=90&strip=all&crop=0%2C0%2C100%2C100&w=2400" alt="Marc-André ter Stegen">
                </div>
                <div class="player-info">
                    <h3>Marc-André ter Stegen</h3>
                    <p>Kiper</p>
                    <div class="player-stats">
                        <div class="stat">
                            <div class="stat-value">18</div>
                            <div class="stat-label">Clean Sheet</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">87%</div>
                            <div class="stat-label">Save Rate</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">32</div>
                            <div class="stat-label">Pertandingan</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Bek -->
            <div class="player-card">
                <div class="player-img">
                    <img src="https://www.fcbarcelona.com/photo-resources/2025/09/09/46af26e5-df57-406a-9bb1-b6f037631f0f/04-Araujo.jpg?width=1200&height=750" alt="Ronald Araújo">
                </div>
                <div class="player-info">
                    <h3>Ronald Araújo</h3>
                    <p>Bek Tengah</p>
                    <div class="player-stats">
                        <div class="stat">
                            <div class="stat-value">2</div>
                            <div class="stat-label">Gol</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">1</div>
                            <div class="stat-label">Asist</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">28</div>
                            <div class="stat-label">Pertandingan</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="player-card">
                <div class="player-img">
                    <img src="https://assets.promediateknologi.id/crop/0x0:0x0/0x0/webp/photo/p3/57/2025/09/29/Jules-Kounde-1200x800-2259914695.jpg" alt="Jules Koundé">
                </div>
                <div class="player-info">
                    <h3>Jules Koundé</h3>
                    <p>Bek Kanan</p>
                    <div class="player-stats">
                        <div class="stat">
                            <div class="stat-value">1</div>
                            <div class="stat-label">Gol</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">4</div>
                            <div class="stat-label">Asist</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">30</div>
                            <div class="stat-label">Pertandingan</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="player-card">
                <div class="player-img">
                    <img src="https://www.fcbarcelona.com/photo-resources/2025/09/09/11a6228b-5034-4d25-9fe3-ea3aafd04dd2/15-Christensen.jpg?width=1200&height=750" alt="Andreas Christensen">
                </div>
                <div class="player-info">
                    <h3>Andreas Christensen</h3>
                    <p>Bek Tengah</p>
                    <div class="player-stats">
                        <div class="stat">
                            <div class="stat-value">1</div>
                            <div class="stat-label">Gol</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">0</div>
                            <div class="stat-label">Asist</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">26</div>
                            <div class="stat-label">Pertandingan</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="player-card">
                <div class="player-img">
                    <img src="https://pbs.twimg.com/media/G2K7LLHWgAAtp1r.jpg" alt="Alejandro Balde">
                </div>
                <div class="player-info">
                    <h3>Alejandro Balde</h3>
                    <p>Bek Kiri</p>
                    <div class="player-stats">
                        <div class="stat">
                            <div class="stat-value">0</div>
                            <div class="stat-label">Gol</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">3</div>
                            <div class="stat-label">Asist</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">24</div>
                            <div class="stat-label">Pertandingan</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Gelandang -->
            <div class="player-card">
                <div class="player-img">
                    <img src="https://cms.disway.id/uploads/f367e544b82c639213ec485bf53da081.jpg" alt="Frenkie de Jong">
                </div>
                <div class="player-info">
                    <h3>Frenkie de Jong</h3>
                    <p>Gelandang Tengah</p>
                    <div class="player-stats">
                        <div class="stat">
                            <div class="stat-value">2</div>
                            <div class="stat-label">Gol</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">8</div>
                            <div class="stat-label">Asist</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">29</div>
                            <div class="stat-label">Pertandingan</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="player-card">
                <div class="player-img">
                    <img src="https://www.fcbarcelona.com/photo-resources/2025/09/10/597a1e13-c0b2-4c93-a2fd-4cc39a9459cc/08-Pedri.jpg?width=1200&height=750" alt="Pedri">
                </div>
                <div class="player-info">
                    <h3>Pedri</h3>
                    <p>Gelandang Tengah</p>
                    <div class="player-stats">
                        <div class="stat">
                            <div class="stat-value">5</div>
                            <div class="stat-label">Gol</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">7</div>
                            <div class="stat-label">Asist</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">25</div>
                            <div class="stat-label">Pertandingan</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="player-card">
                <div class="player-img">
                    <img src="https://www.fcbarcelona.com/photo-resources/2025/09/09/21356702-1d94-49a8-a94a-4170afe7ca16/06-Gavi.jpg?width=1200&height=750" alt="Gavi">
                </div>
                <div class="player-info">
                    <h3>Gavi</h3>
                    <p>Gelandang</p>
                    <div class="player-stats">
                        <div class="stat">
                            <div class="stat-value">2</div>
                            <div class="stat-label">Gol</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">4</div>
                            <div class="stat-label">Asist</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">18</div>
                            <div class="stat-label">Pertandingan</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="player-card">
                <div class="player-img">
                    <img src="https://s.yimg.com/ny/api/res/1.2/PrOxY_AbrXD8dirLhZGCww--/YXBwaWQ9aGlnaGxhbmRlcjt3PTY0MDtoPTQyNztjZj13ZWJw/https://media.zenfs.com/en/madrid_universal_articles_561/487339d13f9dc5b468d699f6a45616bf" alt="İlkay Gündoğan">
                </div>
                <div class="player-info">
                    <h3>İlkay Gündoğan</h3>
                    <p>Gelandang</p>
                    <div class="player-stats">
                        <div class="stat">
                            <div class="stat-value">5</div>
                            <div class="stat-label">Gol</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">9</div>
                            <div class="stat-label">Asist</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">34</div>
                            <div class="stat-label">Pertandingan</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Penyerang -->
            <div class="player-card">
                <div class="player-img">
                    <img src="https://www.fcbarcelona.com/photo-resources/2025/09/10/6dd5aa47-d5fb-45a5-b171-0da82c9c7105/09-Lewandowski.jpg?width=1200&height=750" alt="Robert Lewandowski">
                </div>
                <div class="player-info">
                    <h3>Robert Lewandowski</h3>
                    <p>Striker</p>
                    <div class="player-stats">
                        <div class="stat">
                            <div class="stat-value">20</div>
                            <div class="stat-label">Gol</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">6</div>
                            <div class="stat-label">Asist</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">32</div>
                            <div class="stat-label">Pertandingan</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="player-card">
                <div class="player-img">
                    <img src="https://www.fcbarcelona.com/photo-resources/2025/09/09/a9ecee2c-116c-405c-8524-3127913e7a3c/10-Lamine.jpg?width=1200&height=750" alt="Lamine Yamal">
                </div>
                <div class="player-info">
                    <h3>Lamine Yamal</h3>
                    <p>Winger Kanan</p>
                    <div class="player-stats">
                        <div class="stat">
                            <div class="stat-value">6</div>
                            <div class="stat-label">Gol</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">7</div>
                            <div class="stat-label">Asist</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">33</div>
                            <div class="stat-label">Pertandingan</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="player-card">
                <div class="player-img">
                    <img src="https://www.fcbarcelona.com/photo-resources/2025/09/10/08bbb1ff-004b-4623-a675-66fd1fbfdc8b/11-Raphinha.jpg?width=1200&height=750" alt="Raphinha">
                </div>
                <div class="player-info">
                    <h3>Raphinha</h3>
                    <p>Winger</p>
                    <div class="player-stats">
                        <div class="stat">
                            <div class="stat-value">8</div>
                            <div class="stat-label">Gol</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">10</div>
                            <div class="stat-label">Asist</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">31</div>
                            <div class="stat-label">Pertandingan</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="player-card">
                <div class="player-img">
                    <img src="https://www.fcbarcelona.com/photo-resources/2025/09/09/c83c3cf6-9c12-41c4-b6fa-ea4cfa2bf7dc/07-Ferran_Torres.jpg?width=1200&height=750" alt="Ferran Torres">
                </div>
                <div class="player-info">
                    <h3>Ferran Torres</h3>
                    <p>Penyerang</p>
                    <div class="player-stats">
                        <div class="stat">
                            <div class="stat-value">11</div>
                            <div class="stat-label">Gol</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">3</div>
                            <div class="stat-label">Asist</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">29</div>
                            <div class="stat-label">Pertandingan</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="player-card">
                <div class="player-img">
                    <img src="https://www.fcbarcelona.com/photo-resources/2024/01/30/92483a53-04cf-429d-8ef8-0c2934405496/joao-felix-ok-ok.jpg?width=640&height=400" alt="João Félix">
                </div>
                <div class="player-info">
                    <h3>João Félix</h3>
                    <p>Penyerang</p>
                    <div class="player-stats">
                        <div class="stat">
                            <div class="stat-value">9</div>
                            <div class="stat-label">Gol</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">5</div>
                            <div class="stat-label">Asist</div>
                        </div>
                        <div class="stat">
                            <div class="stat-value">30</div>
                            <div class="stat-label">Pertandingan</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

    <!-- Gallery Section -->
    <section id="gallery">
        <div class="container">
            <div class="section-title">
                <h2>Galeri Barcelona</h2>
            </div>
            <div class="gallery-grid">
                <!-- Gallery Item 1 -->
                <div class="gallery-item">
                    <img src="https://spanish-trails.com/wp-content/uploads/sites/6125/2023/04/ken-russo-IrWOJ1F5Tv4-unsplash-scaled.jpg" alt="Camp Nou">
                    <div class="gallery-overlay">
                        <h3>Camp Nou</h3>
                        <p>Stadion kebanggaan Barcelona dengan kapasitas 99,354 penonton</p>
                    </div>
                </div>
                
                <!-- Gallery Item 2 -->
                <div class="gallery-item">
                    <img src="https://a-cdn.sindonews.net/dyn/620/content/2015/07/31/55/1028118/barcelona-mulai-keranjingan-angkat-6-trofi-VhA-thumb.jpg" alt="Trofi Barcelona">
                    <div class="gallery-overlay">
                        <h3>Koleksi Trofi</h3>
                        <p>Barcelona telah memenangkan 26 gelar La Liga dan 5 Liga Champions</p>
                    </div>
                </div>
                
                <!-- Gallery Item 3 -->
                <div class="gallery-item">
                    <img src="https://cdn.antaranews.com/cache/1200x800/2023/12/21/000_348L434.jpg" alt="Suasana Pertandingan">
                    <div class="gallery-overlay">
                        <h3>Suasana Pertandingan</h3>
                        <p>Atmosfer magis di Camp Nou saat pertandingan berlangsung</p>
                    </div>
                </div>
                
                <!-- Gallery Item 4 -->
                <div class="gallery-item">
                    <img src="https://micms.mediaindonesia.com/storage/app/media/FOTO/mar/batce.jpg" alt="Latihan Tim">
                    <div class="gallery-overlay">
                        <h3>Sesi Latihan</h3>
                        <p>Para pemain berlatih di Ciutat Esportiva Joan Gamper</p>
                    </div>
                </div>
                
                <!-- Gallery Item 5 -->
                <div class="gallery-item">
                    <img src="https://assets.goal.com/images/v3/bltf5b7e6f8614ee8fe/c7c67a0c52b1b5575eda2f2666aa86cff4f955c2.jpeg?auto=webp&format=pjpg&width=3840&quality=60" alt="Supporter Barcelona">
                    <div class="gallery-overlay">
                        <h3>Para Pendukung</h3>
                        <p>Fans Barcelona yang setia dari seluruh penjuru dunia</p>
                    </div>
                </div>
                
                <!-- Gallery Item 6 -->
                <div class="gallery-item">
                    <img src="https://static.promediateknologi.id/crop/0x0:0x0/750x500/webp/photo/p2/80/2025/08/09/Screenshot-2025-08-09-090851-429456428.png" alt="Legenda Barcelona">
                    <div class="gallery-overlay">
                        <h3>Legenda Klub</h3>
                        <p>Pemain legendaris seperti Messi, Xavi, dan Iniesta</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- History Section -->
    <section id="history">
        <div class="container">
            <div class="section-title">
                <h2>Sejarah Barcelona</h2>
            </div>
            <div class="history-content">
                <div class="history-text">
                    <p>Futbol Club Barcelona, biasa dikenal sebagai Barcelona atau Barça, adalah klub sepak bola profesional yang berbasis di Barcelona, Catalonia, Spanyol. Didirikan pada tahun 1899 oleh sekelompok pemain Swiss, Inggris, Jerman, dan Katalan yang dipimpin oleh Joan Gamper, klub ini telah menjadi simbol budaya Katalan dan Catalanisme.</p>
                    <p>Barcelona adalah salah satu klub paling didukung di dunia, dan memiliki persaingan lama dengan Real Madrid, yang dikenal sebagai El Clásico. Klub ini adalah klub sepak bola terkaya di dunia dalam hal pendapatan, dengan omset tahunan sebesar €715,1 juta.</p>
                    <p>Barcelona telah memenangkan 26 gelar La Liga, 31 Copa del Rey, 13 Supercopa de España, 3 Copa Eva Duarte, dan 2 Copa de la Liga, serta 5 Liga Champions UEFA, 4 Piala Winners UEFA (rekor), 5 Piala Super UEFA (rekor), 3 Piala Interkontinental, dan 3 Piala Dunia Antarklub FIFA.</p>
                    <p>Moto klub adalah "Més que un club" (Lebih dari sekadar klub). Tidak seperti banyak klub sepak bola lainnya, para pendukung memiliki dan mengoperasikan Barcelona. Klub ini adalah salah satu dari tiga tim yang tidak pernah terdegradasi dari La Liga, bersama dengan Athletic Bilbao dan Real Madrid.</p>
                </div>
                <div class="history-image">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/0/03/FC_Barcelona_1910.jpg" alt="Sejarah Barcelona">
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer id="contact">
        <div class="container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>Tentang Kami</h3>
                    <p>FC Barcelona adalah lebih dari sekadar klub. Kami adalah simbol kebanggaan Katalan dan memiliki jutaan penggemar di seluruh dunia.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                <div class="footer-column">
                    <h3>Informasi Kontak</h3>
                    <p><i class="fas fa-map-marker-alt"></i> Camp Nou, Barcelona, Spanyol</p>
                    <p><i class="fas fa-phone"></i> +34 902 1899 00</p>
                    <p><i class="fas fa-envelope"></i> info@fcbarcelona.com</p>
                </div>
                <div class="footer-column">
                    <h3>Link Cepat</h3>
                    <p><a href="#home">Beranda</a></p>
                    <p><a href="#players">Pemain</a></p>
                    <p><a href="#gallery">Galeri</a></p>
                    <p><a href="#history">Sejarah</a></p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2023 FC Barcelona. Semua Hak Dilindungi. | Dibuat dengan ❤️ oleh Penggemar Barcelona Dwi Bakti N Dev</p>
            </div>
        </div>
    </footer>

    <script>
        // Mobile Menu Toggle
        document.querySelector('.mobile-menu').addEventListener('click', function() {
            document.querySelector('nav').classList.toggle('active');
        });

        // Smooth Scrolling
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if(targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if(targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                    
                    // Close mobile menu after clicking a link
                    if(window.innerWidth <= 576) {
                        document.querySelector('nav').classList.remove('active');
                    }
                }
            });
        });
    </script>
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\Mengenal Laravel P5\TokoOnline\resources\views/layouts/app.blade.php ENDPATH**/ ?>