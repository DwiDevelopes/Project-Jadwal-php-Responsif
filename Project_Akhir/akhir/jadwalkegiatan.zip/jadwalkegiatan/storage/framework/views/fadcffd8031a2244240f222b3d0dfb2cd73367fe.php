

<?php $__env->startSection('content'); ?>
<h2>Selamat datang di halaman Beranda!</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Mengenal Laravel P5\TokoOnline\resources\views/backend/beranda.blade.php ENDPATH**/ ?>