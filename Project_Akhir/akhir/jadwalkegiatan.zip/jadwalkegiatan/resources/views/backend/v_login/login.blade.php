<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Toko Online</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="icon" type="image/x-icon" href="https://cdn-icons-png.flaticon.com/512/3135/3135715.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css"
        integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <style>
        /* Reset and Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }

        /* Login Container */
        .login-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 450px;
            padding: 40px 35px;
            position: relative;
            overflow: hidden;
            animation: fadeIn 0.8s ease-out;
        }

        /* Header */
        .login-header {
            text-align: center;
            margin-bottom: 35px;
        }

        .login-header h1 {
            color: #333;
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .login-header p {
            color: #777;
            font-size: 15px;
        }

        /* Form Elements */
        .form-group {
            margin-bottom: 25px;
            position: relative;
            animation: slideIn 0.6s ease-out;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .form-control {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e1e5ee;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s ease;
            background-color: #f8f9fa;
        }

        .form-control:focus {
            outline: none;
            border-color: #667eea;
            background-color: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-control:focus+.input-icon {
            color: #667eea;
        }

        .input-icon {
            position: absolute;
            right: 16px;
            top: 40px;
            color: #999;
            transition: all 0.3s ease;
        }

        /* Error Messages */
        .error-message {
            color: #e74c3c;
            font-size: 13px;
            margin-top: 6px;
            display: flex;
            align-items: center;
            animation: shake 0.5s ease-in-out;
        }

        .error-message i {
            margin-right: 6px;
        }

        /* Submit Button */
        .btn-submit {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 7px 14px rgba(102, 126, 234, 0.3);
        }

        .btn-submit:active {
            transform: translateY(0);
        }

        .btn-submit:after {
            content: "";
            position: absolute;
            top: 50%;
            left: 50%;
            width: 5px;
            height: 5px;
            background: rgba(255, 255, 255, 0.5);
            opacity: 0;
            border-radius: 100%;
            transform: scale(1, 1) translate(-50%);
            transform-origin: 50% 50%;
        }

        .btn-submit:focus:not(:active)::after {
            animation: ripple 1s ease-out;
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }

            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes shake {

            0%,
            100% {
                transform: translateX(0);
            }

            10%,
            30%,
            50%,
            70%,
            90% {
                transform: translateX(-5px);
            }

            20%,
            40%,
            60%,
            80% {
                transform: translateX(5px);
            }
        }

        @keyframes ripple {
            0% {
                transform: scale(0, 0);
                opacity: 0.5;
            }

            100% {
                transform: scale(20, 20);
                opacity: 0;
            }
        }

        /* Form Group Animation Delays */
        .form-group:nth-child(1) {
            animation-delay: 0.1s;
        }

        .form-group:nth-child(2) {
            animation-delay: 0.2s;
        }

        .form-group:nth-child(3) {
            animation-delay: 0.3s;
        }

        /* Responsive Design */
        @media (max-width: 480px) {
            .login-container {
                padding: 30px 25px;
            }

            .login-header h1 {
                .login-header h1 {
                    font-size: 24px;
                }
            }
        }
    </style>
    <div class="login-container">
        <div class="login-header">
            <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" width="200px" height="200px"
                style="border-radius: 50%; box-shadow: 0 4px 8px rgba(0,0,0,0.1); margin-bottom: 20px;">
            <h1>Selamat Datang Kembali</h1>
            <p>Login Untuk Memasuki Akun Anda Silahkan Login</p>
        </div>

        <form action="{{ route('proses_login') }}" method="POST" id="loginForm">
            @csrf

            <div class="form-group">
                <label for="email"><i class="fa-solid fa-envelope"></i> Email Address</label>
                <input type="text" name="email" id="email" class="form-control" value="{{ old('email') }}"
                    placeholder="Enter your email address" required>
                <i class="fas fa-envelope input-icon"></i>

                @error('email')
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i>
                    <span>{{ $message }}</span>
                </div>
                @enderror
            </div>

            <div class="form-group">
                <label for="password"><i class="fa-solid fa-user-lock"></i> Password</label>
                <input type="password" name="password" id="password" class="form-control"
                    placeholder="Enter your password" required>
                <i class="fa-solid fa-shop-lock input-icon"></i>

                @error('password')
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i>
                    <span>{{ $message }}</span>
                </div>
                @enderror
            </div>

            @error('login')
            <div class="error-message" style="margin-bottom: 20px;">
                <i class="fas fa-exclamation-circle"></i>
                <span>{{ $message }}</span>
            </div>
            @enderror

            @error('status')
            <div class="error-message" style="margin-bottom: 20px;">
                <i class="fas fa-exclamation-circle"></i>
                <span>{{ $message }}</span>
            </div>
            @enderror

            <div class="check-box" style="margin-bottom: 20px">
                <input type="checkbox" id="remember" name="remember" class="form-check-input">
                <label for="remember" class="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300">Remember
                    me</label>
            </div>


            <button type="submit" class="btn-submit">
                Sign In
            </button>
            <p>silahkan masukan password dan username anda untuk memasuki menu login</p>
            <style>
                p {
                    text-align: center;
                    margin-top: 20px;
                    color: #555;
                    font-size: 14px;
                }
            </style>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const inputs = document.querySelectorAll('.form-control');

            inputs.forEach(input => {

                input.addEventListener('focus', function () {
                    this.parentElement.classList.add('focused');
                });


                input.addEventListener('blur', function () {
                    if (this.value === '') {
                        this.parentElement.classList.remove('focused');
                    }
                });


                if (input.value !== '') {
                    input.parentElement.classList.add('focused');
                }
            });

            const submitButton = document.querySelector('.btn-submit');
            submitButton.addEventListener('click', function (e) {

            });


            const container = document.querySelector('.login-container');
            container.style.transform = 'scale(0.95)';
            setTimeout(() => {
                container.style.transition = 'transform 0.4s ease-out';
                container.style.transform = 'scale(1)';
            }, 100);
        });
    </script>
    <style>
        ::-webkit-scrollbar {
            display: none;
        }
        </style>
</body>

</html>